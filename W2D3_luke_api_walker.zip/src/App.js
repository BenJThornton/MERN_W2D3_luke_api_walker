import logo from './logo.svg';
import './App.css';
import {Switch, Route, Link} from "react-router-dom";
import People from './components/People';
import Planets from './components/Planets';
import Form from './components/Form';
import Error from './components/Error';


function App() {
  return (
    <div className="App">
      <Form/>
      <Switch>
        <Route path="/swplanets/:planetId">
          <Planets/>
        </Route>
        <Route path="/people/:personId">
          <People/>
        </Route>
        <Route path="/error">
          <Error/>
        </Route>
        <Route path="/">
          <h3>This is the home page!</h3>
        </Route>
      </Switch>
    </div>
  );
}

export default App;
