import React, {useState, useEffect} from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { useHistory } from 'react-router-dom/cjs/react-router-dom.min';

const People = (props) => {
    const { personId } = useParams();
    const [ res, setRes ] = useState([]);
    const history = useHistory();

    useEffect(() => {
        axios.get("https://swapi.dev/api/people/" + personId)
            .then(response => { setRes(response.data) })
            .catch(err => { history.push("/error")});
        }, [personId]);


    return (
        <div>
            <h2>{res.name}</h2>
            <p>Height: {res.height}</p>
            <p>Mass: {res.mass}</p>
            <p>Hair Color: {res.hair_color}</p>
            <p>Skin Color: {res.skin_color}</p>
        </div>
    )
}

export default People;