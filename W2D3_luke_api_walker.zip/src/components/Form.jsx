import React, { useState } from 'react';
import { useHistory } from "react-router-dom";



const Form = (props) => {
    const [type, setType] = useState("people")
    const [id, setId] = useState("");

    const history = useHistory();

    console.log(history)

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(type);
        console.log(id);
        history.push("/"+type+"/"+id);

    }
    return (
        <div>
            <h1>Star Wars API</h1>
            <hr />
            <form onSubmit={handleSubmit}>
                <select value={type} onChange={e =>
                    setType(e.target.value)}>
                    <option value="people">people</option>
                    <option value="swplanets">planets</option>
                </select>
                <input type="number" onChange={e => setId(e.target.value)} />
                <button input="submit" onClick={handleSubmit}>Submit</button>
            </form>
        </div>
    )
}

export default Form;