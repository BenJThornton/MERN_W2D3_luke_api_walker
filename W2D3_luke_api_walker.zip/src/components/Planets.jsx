import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { useHistory } from 'react-router-dom/cjs/react-router-dom.min'

const Planets = (props) => {
    const { planetId } = useParams();
    const [ res, setRes ] = useState([]);
    const history = useHistory();

    useEffect(() => {
        axios.get("https://swapi.dev/api/planets/" + planetId)
            .then(res => { setRes(res.data) })
            .catch(err => { history.push("/error") })
    }, [planetId]);

    return (
        <div>
            <h2>Planet: {res.name}</h2>
            <p>Terrain: {res.terrain}</p>
            <p>Climate: {res.climate}</p>
            <p>Gravity: {res.gravity}</p>
            <p>Population: {res.population}</p>
        </div>
    )
}

export default Planets;