import React from 'react';

const Error = (props) => {

    return (
        <div>
            <h2>These aren't the droids you're looking for.</h2>
            <img src="https://starwarsblog.starwars.com/wp-content/uploads/2017/06/25-star-wars-quotes-obi-wan-kenobi-identification-tall.jpg"/>

        </div>
            
    )
}

export default Error;